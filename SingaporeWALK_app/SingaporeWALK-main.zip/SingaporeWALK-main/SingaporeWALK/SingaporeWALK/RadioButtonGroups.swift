//
//  RadioButtonGroups.swift
//  SingaporeWALK
//
//  Created by CHESS on 6/6/22.
//

import SwiftUI

enum Gender: String {
    case yes = "Yes 👍"
    case no = "No 👎"
}

struct RadioButtonGroups: View {
    
    let callback: (String) -> ()
        
        @State var selectedId: String = ""
    
    var body: some View {
        VStack {
                   radioMaleMajority
                   radioFemaleMajority
               }
           }
           
           var radioMaleMajority: some View {
               RadioButtonField(
                   id: Gender.yes.rawValue,
                   label: Gender.yes.rawValue,
                   isMarked: selectedId == Gender.yes.rawValue ? true : false,
                   callback: radioGroupCallback
               )
           }
           
           var radioFemaleMajority: some View {
               RadioButtonField(
                   id: Gender.no.rawValue,
                   label: Gender.no.rawValue,
                   isMarked: selectedId == Gender.no.rawValue ? true : false,
                   callback: radioGroupCallback
               )
           }
           
           func radioGroupCallback(id: String) {
               selectedId = id
               callback(id)
           }
}
