//
//  Banner.swift
//  SingaporeWALK
//
//  Created by CoolAsia on 30/6/22.
//

import SwiftUI

struct Banner: View {
    var body: some View {
        
        ZStack{
        RoundedRectangle(cornerRadius: 25, style: .continuous)
        //                                        .fill(.black.opacity(0.7))
            .fill(Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
            .frame(width: UIScreen.main.bounds.size.width, height: 190)
            .shadow(radius: 10)
            .padding()
            .position(x: UIScreen.main.bounds.size.width/2, y: -95)
        Image("SlantFootSteps")
            .resizable()
            .frame(width: 240, height: 140)
            .position(x: UIScreen.main.bounds.size.width*0.6, y: -70)
        }
    }
}

struct Banner_Previews: PreviewProvider {
    static var previews: some View {
        Banner()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
