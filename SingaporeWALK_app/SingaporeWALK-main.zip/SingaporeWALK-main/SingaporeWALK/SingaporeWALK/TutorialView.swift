//
//  TutorialView.swift
//  SingaporeWALK
//
//  Created by CHESS on 15/7/22.
//

import SwiftUI

struct FullScreenModalView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all)
            StartActivityView()
            Button("Stop Activity") {
                presentationMode.wrappedValue.dismiss()
            }
        }
    }
}

struct TutorialView: View {
    
        @State private var isPresented = false
        
        var body: some View {
            ZStack{
                Banner()
                TabView{
                    VStack{
                        Text("Place the sensors")
                            .font(.title)
                            .bold()
                        Image("exerciseRecommendation")
                        
                            .resizable()
                            .scaledToFill()
                            .frame(width: 500, height: 300)
                            .clipShape(RoundedRectangle(cornerSize: CGSize(width: 30, height: 10)))
                        
                        
                        
                        
                    }.tag(1)
                    VStack{
                        Text("Press start")
                            .font(.title)
                            .bold()
                        Image("exerciseRecommendation")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 500, height: 300)
                            .clipShape(RoundedRectangle(cornerSize: CGSize(width: 30, height: 10)))
                            
                        Button("Start Activity!") {
                            isPresented.toggle()
                        }.padding(20)
                            .background(.green)
                            .clipShape(Capsule())
                            .foregroundColor(.white)
                        
                        
                            .fullScreenCover(isPresented: $isPresented, content: FullScreenModalView.init)
                        
                        
                    }.tag(2)
                   
                }.tabViewStyle(.page)
                    .indexViewStyle(.page(backgroundDisplayMode: .always))
                
            }.navigationTitle("Please follow the instructions")
        }
    
    
}

struct TutorialView_Previews: PreviewProvider {
    static var previews: some View {
        TutorialView()
            .previewDevice("iPad (9th generation)")
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
