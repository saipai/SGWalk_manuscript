//
//  LaunchScreenManager.swift
//  SingaporeWALK
//
//  Created by CHESS on 27/5/22.
//

import Foundation
import Accessibility

enum LaunchScreenPhase{
    case first
    case second
    case completed
}

final class LaunchScreenManager: ObservableObject{
    @Published private(set) var state: LaunchScreenPhase = .first
    
    func dismiss(){
        
        self.state = .second
    
        DispatchQueue.main.asyncAfter(deadline: .now()+1){
            self.state = .completed
        }
    }
}
