//
//  DetailedActivityView.swift
//  SingaporeWALK
//
//  Created by CHESS on 29/6/22.
//

import SwiftUI

struct DetailedActivityView: View {
    @State private var selectedTab: Int = 0
    @State private var birthDate = Date()
    
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    var body: some View {
        
        
        ZStack {
            Banner()
            
            
            //                                   Text("Date is \(birthDate.formatted(date: .long, time: .omitted))")
            
            VStack() {
                HStack{
                    
                    
                    DatePicker("",selection: $birthDate, in: ...Date(), displayedComponents: .date)
                    
                        .frame(width: 100, height:50, alignment: .trailing)
                    
                    Image("fruitninja")
                        .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                        .frame(width: 50.0, height: 50.0)
                        .clipShape(Circle())
                        .overlay{
                            Circle().stroke(.white, lineWidth:4)
                            
                        }
                    Text("Fruit Ninja")
                        .font(.title)
                        .bold()
                    
                }
                ActivityView()
                //                .position(x: UIScreen.main.bounds.size.width/18, y: 30)
                //                    .frame(width: UIScreen.main.bounds.size.width, height: 50, alignment: .center)
                //                               Text("Date is \(birthDate.formatted(date: .long, time: .omitted))")
                
            }
        }.navigationBarTitle("More Details")
        
        
        
        
    }
    
    struct DetailedActivityView_Previews: PreviewProvider {
        static var previews: some View {
            DetailedActivityView()
                .previewDevice("iPad (9th generation)")
            
                .previewInterfaceOrientation(.landscapeLeft)
            DetailedActivityView().previewDevice("iPhone 12 mini")
        }
    }
}
