//
//  DayView.swift
//  SingaporeWALK
//
//  Created by CHESS on 29/6/22.
// Teeeeeeeessssttt

import SwiftUI

struct DayView: View {
    let total = 10
            @State var completed = 0
        @State var color: Color = .green

            let lineWidth: CGFloat = 16
    var body: some View {
//        time against no. of steps
       
                   
                   List {
                       Section{
                           HStack {
                               VStack{
                               Text("Daily Target")
                                   .font(.title)
                                   .bold()
                               Text("30 minutes ")
                                   .font(.title)
                                   .bold()
                                   .foregroundColor(.purple)
                               }
                            Spacer()
                               ZStack {
                                   Text(String(completed*10) + "% Completed" )
                                       .font(.title2)
                                       .bold()
                                   CircularProgressBarView(total: total, completed: completed, lineWidth: lineWidth, color: color).frame(width: 250, height: 250, alignment: .center)
                               }
                                       Button {
                                           withAnimation {
                                               guard completed < total else {
                                                   completed = 0
                                                   return
                                               }
                                               completed += 1
                                           }
                                       } label: {
                                           Text("test")
                                               .padding()
                                               
                                              
                                       }
                                       .padding(.vertical)
                             Spacer()
                               VStack {
                                   Text("Earned Points:").font(.title)
                                   
                                   Text("100").font(.title).bold()
                                       .frame(width: 60, height: 60, alignment: .center)
                                           .padding()
                                           .overlay(
                                               Circle()
                                               .stroke(Color.cyan, lineWidth: 10)
                                               .padding(6))
                               }
                                   }
                                   .padding()
                           
                       }
                       
                       Section {
                           
                           
                           HStack {
                               Text("Daily Active Minutes").font(.title)
                                   .bold()
                               Spacer()
                               VerticalBarChart()
                                   .frame(width: UIScreen.main.bounds.size.width/2.5, height: UIScreen.main.bounds.size.width/2.5, alignment: .center)
                               Spacer()
                           }
                       }
                       
                       Section {
                           
                           
                           HStack {
                               Text("Daily Exercise Intensity").font(.title)
                                   .bold()
                               Spacer()
                               LineGraph()
                                   .frame(width: UIScreen.main.bounds.size.width/2.5, height: UIScreen.main.bounds.size.width/2.5, alignment: .center)
                               Spacer()
                           }
                           
                       }
                       Section{
                           HStack {
                               Text("Daily Average Calories Burnt").font(.title)
                                   .bold()
                               Spacer()
                               HorizontalBarChart()
                                   .frame(width: UIScreen.main.bounds.size.width/2.5, height: UIScreen.main.bounds.size.width/2.5, alignment: .center)
                               Spacer()
                           }
                       }
                       
                       
                       
                       
                   }
               


        
    }
}

struct DayView_Previews: PreviewProvider {
    static var previews: some View {
        DayView()
            .previewDevice("iPad (9th generation)")
            .previewInterfaceOrientation(.landscapeLeft)
        DayView()
            .previewDevice("iPhone 12 mini")
    }
}
