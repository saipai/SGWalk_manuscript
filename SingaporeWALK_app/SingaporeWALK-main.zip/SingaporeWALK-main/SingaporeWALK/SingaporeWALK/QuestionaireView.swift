//
//  QuestionaireView.swift
//  SingaporeWALK
//
//  Created by CHESS on 6/6/22.
//

import SwiftUI

struct QuestionaireView: View {
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    @State private var isActive: Bool = false

    var body: some View {
        
        ZStack {
            Banner()
            Image("dottedFootSteps")
                .resizable()
                .frame(width: 240, height: 140)
                .position(x: UIScreen.main.bounds.size.width*0.6, y: -70)
           
                
                    VStack{
                       
                        TabView{
                           
                                ZStack {
                                    
                                    RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                        .shadow(radius: 10)
                                        .frame(width: 600, height: 450)
                                        .padding()
                                    
                                    VStack {
                                        
                                        Spacer()
                                        Text("Are you feeling good today?")
                                            .font(Font.largeTitle)
                                            .foregroundColor(.white)
                                            .bold()
                                        
                                        
                                        RadioButtonGroups { selected in
                                            print("Selected Gender is: \(selected)")
                                        }
                                        .padding(.leading, 100.0)
                                        Spacer()
                                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                }.tag(1)
                                
                                ZStack {
                                    
                                    RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                        .shadow(radius: 10)
                                        .frame(width: 600, height: 450)
                                        .padding()
                                    
                                    VStack {
                                        
                                        Spacer()
                                        Text("Do you have any physical pain?")
                                            .font(Font.largeTitle)
                                            .foregroundColor(.white)
                                            .bold()
                                        
                                        
                                        RadioButtonGroups { selected in
                                            print("Selected Gender is: \(selected)")
                                        }
                                        .padding(.leading, 100.0)
                                        Spacer()
                                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                }.tag(2)
                                
                                ZStack {
                                    
                                    RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                        .shadow(radius: 10)
                                        .frame(width: 600, height: 450)
                                        .padding()
                                    
                                    VStack {
                                        
                                        Spacer()
                                        Text("Do you have at least 7 hours of rest?")
                                            .font(Font.largeTitle)
                                            .foregroundColor(.white)
                                            .bold()
                                        
                                        
                                        RadioButtonGroups { selected in
                                            print("Selected Gender is: \(selected)")
                                        }
                                        .padding(.leading, 100.0)
                                        Spacer()
                                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                }.tag(3)
                                
                                
                                ZStack {
                                    
                                    RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                        .shadow(radius: 10)
                                        .frame(width: 600, height: 450)
                                        .padding()
                                    
                                    VStack {
                                        
                                        Spacer()
                                        Text("Are you ready for this activity?")
                                            .font(Font.largeTitle)
                                            .foregroundColor(.white)
                                            .bold()
                                        
                                        
                                        RadioButtonGroups { selected in
                                            print("Selected answer is: \(selected)")
                                        }
                                        .padding(.leading, 100.0)
                                        Spacer()
                                        
                                        NavigationLink(destination: TutorialView(), isActive: $isActive){
                                            
                                            ZStack {
                                                RoundedRectangle(cornerRadius: 25, style: .continuous)
                                                    .fill(.green)
                                                    .shadow(radius: 10)
                                                    .frame(width: 600, height: 50)
                                                    
                                                VStack{
                                                    Text("Begin!")
                                                        .bold()
                                                        .font(.title3)
                                                        .foregroundColor(.black)
                                                        
                                                }
                                            }.padding(.bottom, 50)
                                            
                                            
                                               
                                        }
                                        
                                    }.tag(4)
                                }
                                
                                
                            
                        }
                        .tabViewStyle(.page)
                            .indexViewStyle(.page(backgroundDisplayMode: .always))
                        
                       
                        Spacer()
                        
                    }
            
                    
                
            
        }.navigationBarTitle(!isActive ? "Please Answer the Question" : "Back", displayMode: .large)
        
        
        
        
        
    }
}

struct QuestionaireView_Previews: PreviewProvider {
    static var previews: some View {
        QuestionaireView()
            .previewInterfaceOrientation(.landscapeLeft)
            .previewDevice("iPad (9th generation)")
    }
}
