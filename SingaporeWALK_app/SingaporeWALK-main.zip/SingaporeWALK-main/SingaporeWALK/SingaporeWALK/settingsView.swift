//
//  settingsView.swift
//  SingaporeWALK
//
//  Created by CHESS on 3/6/22.
//

import SwiftUI

struct settingsView: View {
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
  
    @State private var isActive: Bool = false
    @State private var selectedTab: Int = 0

    var body: some View {
        NavigationView {
            
            ZStack {
                //                Color(red: 255/255, green: 255/255, blue: 255/255, opacity: 1.0)
                //                    .ignoresSafeArea()
                
                
                Banner()
                Image("dottedFootSteps")
                    .resizable()
                    .frame(width: 240, height: 140)
                    .position(x: UIScreen.main.bounds.size.width*0.6, y: -70)
                
                
                    
                    VStack{
                        Text("Choose Sensors").bold().font(.largeTitle).padding(.top,20)
                        
                        Picker("", selection: $selectedTab) {
                            Text("ZurichMove").tag(0)
                            Text("WitMotion").tag(1)
                            
                        }.pickerStyle(SegmentedPickerStyle())
                            
                           
                            
                        if (selectedTab == 0){
                            List{
                                Section{
                                    
                                }
                            }
                        }
                        else if (selectedTab == 1){
                            DevicesView()
                            
                        }
                    }
                
                
                
                
                
                
                
                
                
                
                
            }.navigationBarTitle( !isActive ? "Settings" : "Back", displayMode: .large)
            
            
        }.navigationViewStyle(.stack)
    }
}

struct settingsView_Previews: PreviewProvider {
    static var previews: some View {
        settingsView()
            .previewDevice("iPad (9th generation)")
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
