//
//  CircularProgressBar.swift
//  SingaporeWALK
//
//  Created by CHESS on 1/7/22.
//

import SwiftUI

struct CircularProgressBarBackground: View {
    let total: Int
    @State var lineWidth: CGFloat = 16
    
    var shortDashSize: CGFloat { 1 }
    func longDashSize(circleWidth: CGFloat) -> CGFloat {
        .pi * circleWidth / CGFloat(total) - shortDashSize
    }
    
    var body: some View {
        GeometryReader { geometry in
            Circle()
                .stroke(Color(white: 230/255),
                        style: StrokeStyle(
                            lineWidth:lineWidth / 1.6,
                            lineCap: .butt,
                            lineJoin: .miter,
                            miterLimit: 0,
                            dash: [longDashSize(circleWidth: geometry.size.width),
                                   shortDashSize
                                  ],
                            dashPhase: 0))
            //        Rotate counter clockwise
                .rotationEffect(.degrees(-90))

        }
        .padding(lineWidth/2)

        
    }
}

struct CircularProgressBarBackground_Previews: PreviewProvider {
    static var previews: some View {
        CircularProgressBarBackground(total: 6)
            
            .previewDevice("iPad (9th generation)")
    }
}
