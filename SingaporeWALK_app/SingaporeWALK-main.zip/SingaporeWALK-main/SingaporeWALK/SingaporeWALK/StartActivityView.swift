//
//  StartActivityView.swift
//  SingaporeWALK
//
//  Created by CHESS on 15/7/22.
//

import SwiftUI
import MapKit

struct StartActivityView: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
    
    @State private var selectedTab: Int = 0
    
    var body: some View {
        
        
        
        ScrollView {
            ZStack{
                Map(coordinateRegion: $region, showsUserLocation: true, userTrackingMode: .constant(.follow))
                    .frame(width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height/3)
                    .position(x: UIScreen.main.bounds.size.width/2, y: 110)
                HStack {
                    Image("camera")
                        .padding(10)
                    
                    Spacer()
                    Image ("locationON").padding(10)
                }.position(x: UIScreen.main.bounds.size.width/2, y: 50)
                
                VStack{
                    Picker("", selection: $selectedTab) {
                        Text("Time Elasped").tag(0)
                        Text("Timer").tag(1)
                        
                    }.pickerStyle(SegmentedPickerStyle())
                        .frame(width: 300, height: 200, alignment: .center)
                        
                    if (selectedTab == 0){
                        TimeElaspedView()
                    }
                    else if (selectedTab == 1){
                        
                    }
                }.padding(.top,200)
            }
        }
        
        
        
        
    }
}
struct StartActivityView_Previews: PreviewProvider {
    static var previews: some View {
        StartActivityView()
            .previewDevice("iPad (9th generation)")
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
