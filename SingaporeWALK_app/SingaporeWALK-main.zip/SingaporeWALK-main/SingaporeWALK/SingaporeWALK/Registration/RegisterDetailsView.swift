//
//  RegisterDetailsView.swift
//  SingaporeWALK
//
//  Created by CoolAsia on 4/7/22.
//

import SwiftUI

struct RegisterDetailsView: View {
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    
    @State private var email = ""
    @State private var username = ""
    @State private var password = ""
    
    
    var body: some View {
        NavigationView {
            ZStack {
                Banner()
                
                VStack{
                    VStack (alignment: .leading){
                        Text("Email: ")
                        TextField("", text: $email, onEditingChanged: {(changed) in
                            print("email onEditingChanged - \(changed)")
                        }){
                            print("email onCommit")
                        }
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.bottom)
                        
                        Text("Username: ")
                        TextField("", text: $email, onEditingChanged: {(changed) in
                            print("Username onEditingChanged - \(changed)")
                        }){
                            print("Username onCommit")
                        }
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.bottom)
                        
                        Text("Password: ")
                        TextField("", text: $email, onEditingChanged: {(changed) in
                            print("Password onEditingChanged - \(changed)")
                        }){
                            print("Password onCommit")
                        }
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.bottom)
                        
                        Text("Confirm Password: ")
                        TextField("", text: $email, onEditingChanged: {(changed) in
                            print("Password onEditingChanged - \(changed)")
                        }){
                            print("Password onCommit")
                        }
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.bottom)
                    }
                    .padding(.horizontal, 300)
                    .padding(.bottom)
                    
                    VStack{
                        
                        HStack{
                            //Back button
                            NavigationLink(destination: ContentView()
                                           //                                    .navigationBarTitle("Welcome!") //this must be empty
                                .navigationBarHidden(true)
                                .navigationBarBackButtonHidden(true)
                                           
                                           
                            )
                            {
                                
                                    
                                Text("Back")
                                        .foregroundColor(.white)
                                    
                                        .frame(width: 100, height: 50)
                                        .background( Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
                                        .cornerRadius(10)
                                
                                
                                
                            }
                            
                            Spacer()
                            
                            //Next button
                            NavigationLink(destination: RegisterDetailsView()
                                           //                                    .navigationBarTitle("Welcome!") //this must be empty
                                .navigationBarHidden(true)
                                .navigationBarBackButtonHidden(true)
                                           
                            )
                            {
                                Button(action:{}) {
                                    
                                    Text("Next")
                                        .foregroundColor(.white)
                                    
                                        .frame(width: 100, height: 50)
                                        .background( Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
                                    //                                            .padding(.top)
                                        .cornerRadius(10)
                                    
                                }
                            }
                            
                        }
                        .padding(.horizontal,300)
                        
                    }
                    .navigationTitle("Register")
                    
                }
            }
            
            
            
        }.navigationViewStyle(.stack)
    }
}

struct RegisterDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        ForEach(["iPad (6th generation)", "iPad Pro (12.9-inch) (5th generation)"], id: \.self) { deviceName in
            RegisterCredView()
                .previewInterfaceOrientation(.landscapeRight)
                .environmentObject(LaunchScreenManager())
                .previewDevice(PreviewDevice(rawValue: deviceName))
                .previewDisplayName(deviceName)
        }
    }
}
