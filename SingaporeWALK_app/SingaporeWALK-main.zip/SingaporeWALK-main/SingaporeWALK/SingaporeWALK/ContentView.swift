//
//  ContentView.swift
//  SingaporeWALK
//
//  Created by CHESS on 25/5/22.
//
// THIS SCREEN IS THE LOGIN SCREEN

import SwiftUI
import FBAuthentication

struct ContentView: View {
    
    @EnvironmentObject var launchScreenManager: LaunchScreenManager
    @EnvironmentObject var userInfo: UserInfo
    
    @State private var username = ""
    @State private var password = ""
    @State private var wrongUsername: Float = 0
    @State private var wrongPassword: Float  = 0
    @State private var showingLoginScreen = false
    
    var body: some View {
        
        LoadingView(startView: SideBarView(),
                    title: "SingaporeWALK",
                    primaryColor: UIColor(named:"primaryColor")!,
                    secondaryColor: UIColor(named: "secondaryColor")!,
                    logoImage: Image("SGWALK Logo Circle"))
        
        
//        NavigationView{
//            //            ScrollView {
//
//            ZStack{
//
//                Color(red: 255/255, green: 167/255, blue: 167/255, opacity: 1.0)
//                    .cornerRadius(15)
//                    .shadow(radius: 20)
//                //                                        .edgesIgnoringSafeArea(.all)
//
//                ScrollView{
//                    HStack{
//                        Spacer()
//
//                        VStack{
//
//                            HStack{
//                                Text("Singapore")
//                                    .font(.system(size:56.0))
//                                    .fontWeight(.bold)
//                                    .foregroundColor(.white)
//                                    .bold()
//                                Text("WALK")
//                                    .font(.system(size:85.0))
//                                    .fontWeight(.bold)
//                                    .foregroundColor(.red)
//                                    .bold()
//                            }
//
//
//                            Text("Let's Walk To A Better Future")
//                                .font(.system(size:35.0))
//                                .foregroundColor(.white)
//                        }
//
//                        circleImage()
//                    }
//
//                    ZStack {
//                        RoundedRectangle(cornerRadius: 25, style: .continuous)
//                            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
//                            .shadow(radius: 10)
//                            .frame(width: UIScreen.main.bounds.size.width/2)
//                            .offset(y:-30)
//
//                        VStack {
//                            VStack{
//                                //                                Spacer()
//                                Text("Login")
//                                    .font(.largeTitle)
//                                    .bold()
//                                    .foregroundColor(.white)
//                                    .padding(.bottom)
//                                //                                Spacer()
//
//                                Text("Username:")
//                                    .font(.title3)
//                                    .bold()
//                                    .foregroundColor(.white)
//                                TextField("", text: $username)
//                                    .padding()
//                                    .frame(width: 300, height: 50)
//                                    .foregroundColor(Color.black.opacity(1))
//                                    .background(Color.white.opacity(1))
//                                    .cornerRadius(10)
////                                SET BORDER TO RED WHEN GIVEN INPUT IS INCORRECT
//                                    .border(.red, width: CGFloat(wrongUsername))
//
//                                Text("Password:")
//                                    .font(.title3)
//                                    .bold()
//                                    .foregroundColor(.white)
////                                MAKE PASSWORD AS DOTS
//                                SecureField("", text: $password)
//                                    .padding()
//                                    .frame(width: 300, height: 50)
//                                    .foregroundColor(Color.black.opacity(1))
//                                    .background(Color.white.opacity(1))
//                                    .cornerRadius(10)
//                                    .border(.red, width: CGFloat(wrongPassword))
//
//                            }
//                            .padding(.bottom)
//
//                            VStack {
//                                NavigationLink(destination: SideBarView()
//                                               //                                    .navigationBarTitle("Welcome!") //this must be empty
//                                    .navigationBarHidden(true)
//                                    .navigationBarBackButtonHidden(true)
//                                               ,
//                                               isActive: $showingLoginScreen
//
//                                )
//                                {
//                                    Button(action:{authenticateUser(username: username, password: password)}) {
//
//                                        Text("Login")
//                                            .foregroundColor(.white)
//
//                                            .frame(width: 300, height: 50)
//                                            .background( Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
//                                        //                                            .padding(.top)
//                                            .cornerRadius(10)
//
//                                    }
//
//                                }
//                                //                                .navigationBarTitle("Welcome! " + username)
//
//
//                                Text("or")
//                                    .font(.title)
//                                    .foregroundColor(.white)
//
//                                NavigationLink(destination: RegisterCredView()
//                                               //                                    .navigationBarTitle("Welcome!") //this must be empty
//                                    .navigationBarHidden(true)
//                                    .navigationBarBackButtonHidden(true)
//                                               //                                               isActive: $showingLoginScreen
//                                ){
//                                    //
//                                    Text("Register")
//                                        .foregroundColor(.white)
//
//                                        .frame(width: 300, height: 50)
//                                        .background(Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
//                                        .cornerRadius(10)
//
//
//                                    //                                    .navigationBarTitle("Register")
//
//                                }
//                            }
//                            .padding(.bottom,40)
//                        }
//                        .padding(.bottom,30)
//
//                    }
//                    .padding()
//
//
//                }
//
//
//            }
//
//
//
//
//
//            //            }
//            .navigationBarHidden(true)
//            .navigationBarBackButtonHidden(true)
//
//        }.navigationViewStyle(StackNavigationViewStyle())
        
//        DISMISS SPLASH SCREEN
//            .onAppear{
//                DispatchQueue
//                    .main
//                    .asyncAfter(deadline: .now() + 3)  {
//                        launchScreenManager.dismiss()
//                    }
//            }
        
        
    }
    
    
//    FUNCTION TO AUTENTICAT USER
    func authenticateUser(username: String, password: String) {
        if username.lowercased() == "123" {
            wrongUsername = 0
            if password.lowercased() == "abc" {
                wrongPassword = 0
                showingLoginScreen = true
            } else {
                wrongPassword = 2
            }
        } else {
            wrongUsername = 2
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ForEach(["iPad (6th generation)", "iPad Pro (12.9-inch) (5th generation)"], id: \.self) { deviceName in
            ContentView()
                .previewInterfaceOrientation(.landscapeRight)
                .environmentObject(LaunchScreenManager())
                .previewDevice(PreviewDevice(rawValue: deviceName))
                .previewDisplayName(deviceName)
                .environmentObject(UserInfo())
        }
    }
}



