//
//  summaryView.swift
//  SingaporeWALK
//
//  Created by CHESS on 3/6/22.
//

import SwiftUI
import SwiftUICharts
import ACarousel

struct Item: Identifiable {
    let id = UUID()
    let image: Image
    
}

let roles = ["exerciseIntensity", "exerciseRecommendation"]


struct summaryView: View {
    @State var selection: Int? = nil
    @State var steps: Int = 0
    @State var circleColour: Bool = false
    
    @State var circleProgress: CGFloat = 0.0
    @State private var isActive: Bool = false

    let items: [Item] = roles.map { Item(image: Image($0)) }
    
    private let data: [Int] = Array(1...20)
    private let colors: [Color] = [.red, .green, .blue, .yellow]
    
    // Flexible, custom amount of columns that fill the remaining space
    private let numberColumns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // Adaptive, make sure it's the size of your smallest element.
    private let adaptiveColumns = [
        GridItem(.adaptive(minimum: 280))
    ]
    
    // Fixed, creates columns with fixed dimensions
    private let fixedColumns = [
        GridItem(.fixed(200)),
        GridItem(.fixed(200))
    ]
    
    
    
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    
    var body: some View {
        
        NavigationView {
            
            ZStack {
//                Color(red: 255/255, green: 255/255, blue: 255/255, opacity: 1.0)
//                    .ignoresSafeArea()
                
                
                Banner()
                
                
                TabView{
                    
                    ScrollView{
                        
                        Spacer()
                        Text("Summary")
                            .font(.largeTitle)
                            .bold()
                        Button(action: {self.startLoading()}) {
                            VStack {
                                ZStack {
                                    Circle()
                                    
                                        .stroke(Color.gray, lineWidth: 15)
                                        .frame(width: 220, height: 220)
                                    
                                    Circle()
                                        .trim(from: 0.0, to: circleProgress)
                                        
                                        .stroke(circleColour == true ? .green : .yellow, lineWidth: 15)
                                        .frame(width: 220, height: 220)
                                        .rotationEffect(Angle(degrees: -90))
                                    Text("Weekly Activity \nTime Goal \n" + "\(Int(self.circleProgress*100))%" + "\nCompleted")
                                        .font(.custom("HelveticaNeue", size: 20.0))
                                    
                                }
                                
                                
                            }.padding(.bottom,10)
                                
                        }
                        
                    Divider()
                    
                        ScrollViewReader {
                            scroller in
                            Button(action: { let targetId = 10
                                scroller.scrollTo(targetId, anchor: .bottom)}) {
                                        Image("arrowDown")
                                        .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                        .renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                                        .frame(width: 50.0, height: 50.0)
                                        .position(x: UIScreen.main.bounds.size.width/3 + 10, y: 0)
                                        .padding(.top, 20.0)
                                    }
                            
                            LazyVGrid(columns: adaptiveColumns, spacing: 1) {
                                NavigationLink (destination: StatsView(), isActive: $isActive)
                                {
                                    HStack {
                                        ZStack {
                                            
                                           SummaryCard()
                                            
                                            
                                            
                                            VStack {
                                                
                                                Spacer()
                                                Text("You Exercised For ")
                                                    .font(.title)
                                                    .bold()
                                                    .foregroundColor(.white)
                                                
                                                Text(String(steps)).font(.system(size: 100.0))
                                                    .foregroundColor(.yellow)
                                                
                                                
                                                Text("Minutes Today!")
                                                    .font(.title)
                                                    .bold()
                                                    .foregroundColor(.white)
                                                Spacer()
                                                
                                                
                                                
                                            }
                                            
                                            
                                            
                                        }
                                        
                                    }
                                }.id(1)
                                
                                
                                
                                NavigationLink (destination: StatsView())
                                {
                                    HStack {
                                        
                                        ZStack {
                                            
                                           SummaryCard()
                                            
                                            
                                            VStack {
                                                Spacer()
                                                Text("30th Jun")
                                                    .font(.title)
                                                    .bold()
                                                    .foregroundColor(.white)
                                                
                                                    .padding(.top, 15)
                                                Text("6 minute walk")
                                                    .bold()
                                                    .foregroundColor(.white)

//                                                LineChartView(data: [2,5,10,7,8,6,11,15,12], title: "Speed", legend: "6-minute Walk")
                                                //                                                PieChartView(data: [5,1], title: "Completed Time", legend: "90% completed") // legend is optional
                                                ZStack {
                                                    SummaryGraphCards()
                                                    LineGraph()
                                                    .frame(width: 280, height:150)

                                                }
                                                
                                                Spacer()
                                            }
                                        }
                                        
                                    }
                                }
                                
                                NavigationLink (destination: StatsView())
                                {
                                    
                                        
                                        ZStack {
                                            
                                           SummaryCard()
                                            
                                            
                                            VStack {
                                                Spacer()
                                                Text("Calories Burnt")
                                                    .font(.title)
                                                    .bold()
                                                    .foregroundColor(.white)
                                                Text("(kcal)")
                                                    .bold()
                                                    .foregroundColor(.white)
//                                                PieChartView(data: [60,100], title: "Water", legend: "60% completed") // legend is optional
                                                ZStack {
                                                    SummaryGraphCards()
                                                    HorizontalBarChart()
                                                    .frame(width: 250, height:150)

                                                }
                                                
                                                Spacer()
                                            }
                                        }
                                        
                                    
                                }.id(10)
                                
                            }.padding(.bottom, 10.0)
                           
                            Button(action: { let targetId = 1
                                scroller.scrollTo(targetId, anchor: .bottom)}) {
                                        Image("arrowUp")
                                        .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                        .renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                                        .frame(width: 50.0, height: 50.0)
                                        .position(x: UIScreen.main.bounds.size.width/3 + 10, y: 0)
                                        .padding(.bottom, 20.0)
                                    }
                            
                            
                        }
                    
                    }
                    .tag(0)
                    
                    CategoryView().tag(1)
                    HPBInfoView().tag(2)
                    
                }
                
                .tabViewStyle(.page)
                .indexViewStyle(.page(backgroundDisplayMode: .always))
            }.navigationBarTitle( !isActive ? "Welcome Back" : "Back", displayMode: .large)
            
            
        }.navigationViewStyle(.stack)
        
    }
    
    func startLoading() {
        _ = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
            withAnimation() {
                self.circleProgress += 0.01
                if self.circleProgress >= 1.0 {
                    timer.invalidate()
                }
                if self.circleProgress > 0.5 {
                    circleColour=true
                }
            }
        }
    }
    
    
    
    
}


struct summaryView_Previews: PreviewProvider {
    static var previews: some View {
        ForEach(["iPad (9th generation)", "iPad Pro (12.9-inch) (5th generation)"], id: \.self) { deviceName in
            summaryView()
                .previewInterfaceOrientation(.landscapeRight)
                .environmentObject(LaunchScreenManager())
                .previewDevice(PreviewDevice(rawValue: deviceName))
                .previewDisplayName(deviceName)
        }
    }
}
