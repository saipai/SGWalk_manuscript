//
//  circleImage.swift
//  SingaporeWALK
//
//  Created by CHESS on 25/5/22.
//

import SwiftUI

struct circleImage: View {
    var body: some View {
        
        Image("SGWALK Logo Circle")
            .resizable()
            .frame(width: 200.0, height: 200.0)
            .clipShape(Circle())
            .overlay{
                Circle().stroke(.white, lineWidth:4)
            }
            .shadow(radius: 7)
            
            
    }
}

struct circleImage_Previews: PreviewProvider {
    static var previews: some View {
        circleImage()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
