//
//  SummaryGraphCards.swift
//  SingaporeWALK
//
//  Created by CHESS on 30/6/22.
//

import SwiftUI

struct SummaryGraphCards: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 25, style: .continuous)
        //                                        .fill(.black.opacity(0.7))
            .fill(Color(red: 250/255, green: 250/255, blue: 250/255))
            .frame(width: 280, height: 240)
            .shadow(radius: 10)
            

    }
}

struct SummaryGraphCards_Previews: PreviewProvider {
    static var previews: some View {
        SummaryGraphCards().previewDevice("iPad (9th generation)")
    }
}
