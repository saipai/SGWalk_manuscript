//
//  SideBarView.swift
//  SingaporeWALK
//
//  Created by CHESS on 9/6/22.
//
//THE VIEW FOR THE SIDE MENU

import SwiftUI
import FBAuthentication

struct SideBarView: View {
//    FOR SELCETING DEFAULT LIST ITEM
    @State private var selectedView: Int? = 0
//    FOR DIFFERENT DEVICE TYPE
    @State private var navigationForIpad = false
    @State private var showProfile = false
    
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var userInfo: UserInfo
        
    var body: some View {
        
        NavigationView{
            
            
            VStack {
                Image("elderly")
                    .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                    .frame(width: 200.0, height: 150.0)
                    .clipShape(Circle())
                
                    .overlay{
                        Circle().stroke(Color(red: 24/255, green: 28/255, blue: 98/255), lineWidth:4)
                    }
                    .shadow(radius: 7)
                
                Button {
                    showProfile.toggle()
                } label: {
                    Text(userInfo.user.name)
                        .font(.largeTitle)
                        .bold()
                } .sheet(isPresented: $showProfile) {
                    ProfileView()
                }
                
                List{
                    
                    
                    
//                    SELECT THE SUMMARY BY DEFAULT
                    NavigationLink (destination: summaryView().navigationBarTitleDisplayMode(.inline) .navigationBarHidden(navigationForIpad), tag: 0, selection: self.$selectedView){
                        
                        
                        
                        
                        HStack {
                            
                            Image("summaryIcon")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 50.0, height: 50.0)
                                .clipShape(Rectangle())
                            
                            
                            
                            
                            Text("Summary")
                                .font(.title)
                                .bold()
                            
                            
                            
                        }
                        
                    }
                    
                    
                    
                    
                    
                    NavigationLink (destination: logActivityView()
                        .navigationBarTitleDisplayMode(.inline)
                        .navigationBarHidden(navigationForIpad)
                                    , tag: 1, selection: self.$selectedView){
                        HStack {
                            
                            Image("logActivityIcon")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 50.0, height: 50.0)
                                .clipShape(Rectangle())
                            
                            
                            
                            
                            Text("Log Activity")
                                .font(.title)
                                .bold()
                        }
                    }
                    
                    
                    NavigationLink (destination: logActivityView()
                        .navigationBarTitleDisplayMode(.inline)
                        .navigationBarHidden(navigationForIpad)
                                    , tag: 2, selection: self.$selectedView){
                        HStack {
                            
                            Image("rewardsIcon")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 50.0, height: 50.0)
                                .clipShape(Rectangle())
                            
                            
                            
                            
                            Text("Rewards")
                                .font(.title)
                                .bold()
                        }
                    }
                    
                    
                    
                    
                    NavigationLink (destination: settingsView()
                        .navigationBarTitleDisplayMode(.inline)
                        .navigationBarHidden(navigationForIpad)
                                    , tag: 3, selection: self.$selectedView){
                        HStack {
                            
                            Image("settingsIcon")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 50.0, height: 50.0)
                                .clipShape(Circle())
                            
                            
                            
                            
                            Text("Settings")
                                .font(.title)
                                .bold()
                            
                            
                        }
                    }
                    
                    
                }.listStyle(.plain)
                if (selectedView == 0){
                    Image("Mascot Summary")
                        .resizable()
                        .frame(width: 150.0, height: 150.0)
                }
               
                
                else if (selectedView == 1){
                    Image("Mascot Log")
                        .resizable()
                        .frame(width: 150.0, height: 150.0)
                }
                else if (selectedView == 2){
                    Image("Mascot Rewards")
                        .resizable()
                        .frame(width: 150.0, height: 150.0)
                }
                else if (selectedView == 3){
                    Image("Mascot Settings")
                        .resizable()
                        .frame(width: 150.0, height: 150.0)
                }
                    Button("Log Out") {
                        FBAuth.logout { result in
                            switch result {
                            case .success(_):
                                print("Logged out")
                            case .failure(let error):
                                print(error.localizedDescription)
                            }
                        }
                    }.foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(Color.red)
                        .cornerRadius(10)
                        .padding()
                        .onTapGesture {
                            self.presentationMode.wrappedValue.dismiss()

                        }
                    
                
            } .navigationBarHidden(navigationForIpad)
            
            
            
            
            
            
            
            
            
            
        }
//        DIFFERENT VIEW TYPE FOR IPHONE AND IPAD
        .onAppear{
            let device = UIDevice.current
            if device.model == "iPad"{
                self.selectedView = 0
                navigationForIpad = true
            }
            else if device.model == "iPhone"{
                navigationForIpad = false
                self.selectedView = -1
                
            }
            
        }
        
        
        
        
        
        
        
        
        
        
    }
}

struct SideBarView_Previews: PreviewProvider {
    static var previews: some View {
        SideBarView()
            .previewDevice("iPad (9th generation)")
            .previewInterfaceOrientation(.landscapeLeft)
            
    }
}
