//
//  SummaryCard.swift
//  SingaporeWALK
//
//  Created by CHESS on 30/6/22.
//

import SwiftUI

struct SummaryCard: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 25, style: .continuous)
        //                                        .fill(.black.opacity(0.7))
            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
            .frame(width: 300, height: 300)
            .shadow(radius: 10)
            .padding()
    }
}

struct SummaryCard_Previews: PreviewProvider {
    static var previews: some View {
        SummaryCard()
    }
}
