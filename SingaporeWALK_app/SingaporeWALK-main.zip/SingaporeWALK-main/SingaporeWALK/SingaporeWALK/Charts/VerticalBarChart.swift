//
//  VerticalBarChart.swift
//  SingaporeWALK
//
//  Created by CHESS on 30/6/22.
//

import SwiftUI
import SwiftUICharts

struct VerticalBarChart: View {
    var body: some View {
        
                let highMin = Legend(color: .green, label: "> 40 min", order: 4)
                let mediumMin = Legend(color: .orange, label: "10 - 39 min", order: 3)
                
                let lowMin = Legend(color: .red, label: "0 - 9 min", order: 2)
                let midPoint = Legend(color: .blue, label: "Goal", order: 1)

                let limit = DataPoint(value: 10, label: "10 min", legend: midPoint)


                let points: [DataPoint] = [
                    .init(value: 10, label: "Day 1", legend: mediumMin),
                   
                    .init(value: 25, label: "Day 2", legend: mediumMin),
                    .init(value: 15, label: "Day 3", legend: highMin),

                    .init(value: 5, label: "Day 4", legend: lowMin),
                  
              
                    .init(value: 33, label: "Day 5", legend: highMin),
                    .init(value: 45, label: "Day 6", legend: highMin),
                    .init(value: 7, label: "Day 7", legend: lowMin),
                ]

                BarChartView(dataPoints: points, limit: limit)
    }
}

struct VerticalBarChart_Previews: PreviewProvider {
    static var previews: some View {
        VerticalBarChart()
    }
}
