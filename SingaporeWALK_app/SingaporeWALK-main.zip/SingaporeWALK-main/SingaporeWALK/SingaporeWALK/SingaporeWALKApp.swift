//
//  SingaporeWALKApp.swift
//  SingaporeWALK
//
//  Created by CHESS on 25/5/22.
//

import SwiftUI
import Firebase
import FBAuthentication

@main
struct SingaporeWALKApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    
//    @StateObject var launchScreenManager = LaunchScreenManager()
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView().environmentObject(UserInfo())
                
//                if launchScreenManager.state != .completed{
//                    LaunchScreenView()
//
//                }
            }
//            .environmentObject(launchScreenManager)
        }
    }
}
