//
//  HPBInfoView.swift
//  SingaporeWALK
//
//  Created by CHESS on 23/6/22.
//


import SwiftUI
import ACarousel

struct Items: Identifiable {
    let id = UUID()
    let image: Image
    
}

struct HPBInfoView: View {
    @State private var isActive: Bool = false
    
    let items: [Items] = roles.map { Items(image: Image($0)) }
    
    var body: some View {
        Link (destination: URL(string: "https://www.healthhub.sg/sites/assets/Assets/Programs/pa-lit/pdfs/Singapore_Physical_Activity_Guidelines.pdf")!)
        {
            VStack {
                
                Text("Click on the poster to view the full guidelines")
                    .font(.subheadline)
                    .frame(maxWidth: .infinity, alignment: .center)
                
                
                ACarousel(items,
                          spacing: 10,
                          headspace: 10,
                          sidesScaling: 0.7,
                          isWrap: true,
                          autoScroll: .active(10)) { items in
                    items.image
                        .resizable()
                        .scaledToFit()
                        .frame(height: UIScreen.main.bounds.size.height * 0.75)
                        .cornerRadius(25)
                }
                          .frame(height: UIScreen.main.bounds.size.height * 0.70)
                          .padding(.bottom, 50.0)
            }.padding(.top, 10)
                .padding(.bottom, 10)
            
        }.navigationBarTitle( !isActive ? "HPB Guidelines" : "Back", displayMode: .large)
    }
    
    struct HPBInfoView_Previews: PreviewProvider {
        static var previews: some View {
            HPBInfoView()
                .previewDevice("iPad (9th generation)")
                .previewInterfaceOrientation(.landscapeRight)
            HPBInfoView()
                .previewDevice("iPhone 12 mini")
        }
    }
}
