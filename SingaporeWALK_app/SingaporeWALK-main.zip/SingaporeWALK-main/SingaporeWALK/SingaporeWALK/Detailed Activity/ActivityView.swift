//
//  ActivityView.swift
//  SingaporeWALK
//
//  Created by CHESS on 5/7/22.
//

import SwiftUI

struct ActivityView: View {
    var body: some View {
        
                
                
                List {
                    
                    Section{
                        HStack {
                            VStack{
                                Text("Duration")
                                    .font(.title)
                                    .bold()
                                
//                                    .shadow(radius: 7)
                                
                                Text("10 minutes ")
                                    .font(.title)
                                    .bold()
                                    .foregroundColor(.purple)
                                
                                
                            }
                            
                            .padding(.vertical)
                            Spacer()
                            
                            VStack{
                                Text("Calories Burnt")
                                    .font(.title)
                                    .bold()
                                
//                                    .shadow(radius: 7)
                                
                                Text("10KCAL ")
                                    .font(.title)
                                    .bold()
                                    .foregroundColor(.orange)
                                
                                
                            }
                            Spacer()
                            
                            VStack {
                                Text("Earned Points:").font(.title)
                                
                                Text("48").font(.title).bold()
                                    .frame(width: 60, height: 60, alignment: .center)
                                    .padding()
                                    .overlay(
                                        Circle()
                                            .stroke(Color.cyan, lineWidth: 10)
                                            .padding(6))
                            }
                        }
                        .padding()
                        
                    }
                    
                    Section {
                        
                        
                        HStack {
                            Text("Movement Intensity").font(.title)
                                .bold()
                            Spacer()
LineGraph()
                                .frame(width: UIScreen.main.bounds.size.width/2.5, height: UIScreen.main.bounds.size.width/2.5, alignment: .center)
                            Spacer()
                        }
                    }
                    
                    Section{
                        HStack {
                            Text("Calories Comparison\n(KCAL)").font(.title)
                                .bold()
                            Spacer()
                            HorizontalBarChart()
                                .frame(width: UIScreen.main.bounds.size.width/2.5, height: UIScreen.main.bounds.size.width/2.5, alignment: .center)
                            Spacer()
                        }
                    }
                    
                    
                    
                }
            
            
            
            
            
        }
    }
    
    struct ActivityView_Previews: PreviewProvider {
        static var previews: some View {
            ActivityView().previewDevice("iPad (9th generation)").previewInterfaceOrientation(.landscapeLeft)
        }
    }

