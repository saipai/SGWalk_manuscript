//
//  DevicesView.swift
//  SingaporeWALK
//
//  Created by CHESS on 27/7/22.
//

import SwiftUI
import CoreBluetooth

class BluetoothViewModel: NSObject, ObservableObject, CBPeripheralDelegate{
    private var CentralManager: CBCentralManager?
    
    private var peripherals: [CBPeripheral] = []
    @Published var peripheralNames: [String] = []
    
    private var connectedPeripheral: CBPeripheral?
    @Published var connectedPeripheralName: String = ""
    
    
    override init() {
        super.init()
        self.CentralManager = CBCentralManager(delegate: self, queue: .main)
    }
}

extension BluetoothViewModel: CBCentralManagerDelegate{
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        //        start scanning when powered on
        if central.state == .poweredOn {
            self.CentralManager?.scanForPeripherals(withServices: nil)
        }
        else if central.state == .poweredOff{
            //            ALert user to turn on Bluetooth
        }
        else if central.state == .resetting{
            //            Wait for next state update and consider logging interruption of Bluetooth service
        }
        else if central.state == .unauthorized{
            // Alert user to enable Bluetooth permission in app Setting
        }
        else if central.state == .unsupported{
            // Alert user their device does not support Bluetooth and app will not work as expected
        }
        else if central.state == .unknown{
            // Wait for next state update
        }
        
        
    }
    
    func connect(peripheral: CBPeripheral)
    {
        CentralManager?.connect(peripheral, options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        //        appending the list
        if !peripherals.contains(peripheral){
            self.peripherals.append(peripheral)
            self.peripheralNames.append(peripheral.name ?? "unamed device")
            
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        // Successfully connected. Store reference to peripheral if not already done.
        if !peripherals.contains(peripheral){
            self.connectedPeripheral = peripheral
            self.connectedPeripheralName.append(peripheral.name ?? "unamed device")
            
        }
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        // Handle error
    }
    
}

struct DevicesView: View {
    @ObservedObject private var bluetoothViewModel = BluetoothViewModel()
    
    var body: some View {
        List(bluetoothViewModel.peripheralNames, id: \.self){
            peripheral in
            HStack{
                Text(peripheral)
                Spacer()
                Button("Connect"){
                    print("aaaaaaaaaa" + bluetoothViewModel.connectedPeripheralName)
                                          
                                  
                                  
                }
                
            }
        }
        .navigationTitle("Nearby Sensors")
    }
}

struct DevicesView_Previews: PreviewProvider {
    static var previews: some View {
        DevicesView().previewDevice("iPad (9th generation)")
    }
}
