//
//  LaunchScreenView.swift
//  SingaporeWALK
//
//  Created by CHESS on 27/5/22.
//

import SwiftUI

//Splash Screen
struct LaunchScreenView: View {

    @EnvironmentObject var launchScreenManager: LaunchScreenManager
    
    @State private var firstPhaseIsAnimating: Bool = false
    @State private var secondPhaseIsAnimating: Bool = false

    
    private let timer = Timer.publish(every: 0.65, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack{
//            RoundedRectangle(cornerRadius: 25, style: .continuous)
//            //                                        .fill(.black.opacity(0.7))
//                .fill(Color(red: 255/255, green: 34/255, blue: 63/255, opacity: 1.0))
//                .frame(width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height*0.90)
//                .shadow(radius: 25)
//                .padding()
            Image("Launch-screen-background")
                .resizable()
                .aspectRatio(UIImage(named: "Launch-screen-background")!.size, contentMode: .fill)
                .edgesIgnoringSafeArea(.all)
                
            
            logo
//            background
//
//                .position(x: UIScreen.main.bounds.size.width/2, y: -95)
            Text("SingaporeWALK")
                .font(.system(.largeTitle, design: .rounded))
                .fontWeight(.bold)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .offset(y:260)
                
                
                
                
        }
        .onReceive(timer){ input in
            
            switch launchScreenManager.state{
            case .first:
                withAnimation(.spring()){
                    //with continuous scaling
                    firstPhaseIsAnimating.toggle()
                }
            case .second:
                withAnimation(.easeInOut){
                    //with continuous scaling
                    secondPhaseIsAnimating.toggle()
                }
            default: break
            }
            //firstphase with continuous scaling
            
        }.opacity(secondPhaseIsAnimating ? 0 : 1)
    }
}

struct LaunchScreenView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchScreenView()
            .environmentObject(LaunchScreenManager())
            .previewInterfaceOrientation(.landscapeLeft)
            .previewDevice("iPad (9th generation)")
    }
}

private extension LaunchScreenView{
    
    var background: some View{
//        Color("Launch-screen-background")
        Color(red: 255/255, green: 34/255, blue: 63/255, opacity: 1.0)            //.edgesIgnoringSafeArea(.all)
        
    }
    
    var logo: some View{
        Image ("SGWALK Logo Circle")
            .resizable()
            .frame(width: 300.0, height: 300.0)
            .clipShape(Circle())
            .scaleEffect(firstPhaseIsAnimating ? 0.6 : 1)
            .scaleEffect(secondPhaseIsAnimating ? UIScreen.main.bounds.size.height / 4 : 1)
            .position(x: 60 + UIScreen.main.bounds.size.width/2, y: UIScreen.main.bounds.size.height/2)
        //getting device screen height with UIScreen.main....

    }
}
