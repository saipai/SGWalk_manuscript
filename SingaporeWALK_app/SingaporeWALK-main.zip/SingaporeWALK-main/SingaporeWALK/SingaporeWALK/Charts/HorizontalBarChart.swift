//
//  HorizontalBarChart.swift
//  SingaporeWALK
//
//  Created by CHESS on 30/6/22.
//

import SwiftUI
import SwiftUICharts
struct HorizontalBarChart: View {
    var body: some View {
        
        let low = Legend(color: .red, label: "< 1749", order: 1)
        let mid = Legend(color: .yellow, label: " >1750", order: 1)
        let high = Legend(color: .green, label: " > 2499", order: 1)

        let points: [DataPoint] = [
            
            .init(value: 1500, label: "Mon", legend: low),
            .init(value: 1800, label: "Tue", legend: mid),
            .init(value: 2500, label: "Wed", legend: high),
            
        ]

        HorizontalBarChartView(dataPoints: points)
        
        
    }
}

struct HorizontalBarChart_Previews: PreviewProvider {
    static var previews: some View {
        HorizontalBarChart().previewDevice("iPad (9th generation)")
    }
}
