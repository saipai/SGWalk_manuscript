//
//  SignInWithEmailView.swift
//  Signin With Apple
//
//  Created by Stewart Lynch on 2020-03-19.
//  Copyright © 2020 CreaTECH Solutions. All rights reserved.
//

import SwiftUI

struct SignInWithEmailView: View {
    @EnvironmentObject var userInfo: UserInfo
    @State var user: UserViewModel = UserViewModel()
    @Binding var showSheet: Bool
    @Binding var action: LoginView.Action?
    @State private var showAlert = false
    @State private var authError: EmailAuthError?
    
    let lightGreyColor = Color(red: 239.0/255.0, green: 243.0/255.0, blue: 244.0/255.0, opacity: 1.0)
    var primaryColor: UIColor
    var secondaryColor: UIColor
    var body: some View {
        VStack {
            
            VStack {
                TextField("Email Address",
                          text: self.$user.email)
                    .autocapitalization(.none)
                    .keyboardType(.emailAddress)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(10)
                    .background(LinearGradient(gradient: Gradient(colors: [lightGreyColor, lightGreyColor]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .cornerRadius(20)
                .shadow(color: .gray, radius: 3)
            }.padding(5)
            
            VStack {
                SecureField("Password", text: $user.password)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(10)
                    .background(LinearGradient(gradient: Gradient(colors: [lightGreyColor, lightGreyColor]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .cornerRadius(20)
                .shadow(color: .gray, radius: 3)
            }.padding(5)
            
            
            HStack {
                Spacer()
                Button {
                    action = .resetPW
                    showSheet = true
                } label: {
                    Text("Forgot Password")
                }
                .foregroundColor(Color(primaryColor))
            }
            .padding(.bottom)
            VStack(spacing: 10) {
                Button {
                    FBAuth.authenticate(withEmail: self.user.email,
                                        password: self.user.password) { (result) in
                                            switch result {
                                            case .failure(let error):
                                                self.authError = error
                                                self.showAlert = true
                                            case .success:
                                                print("Signed in")
                                            }
                    }
                } label: {
                    Text("Login")
                        .padding(.vertical, 15)
                        .frame(width: 200)
                        .background(Color(primaryColor))
                        .cornerRadius(8)
                        .foregroundColor(.white)
                        .opacity(user.isLogInComplete ? 1 : 0.75)
                }.disabled(!user.isLogInComplete)
                Button {
                    action = .signUp
                   showSheet = true
                } label: {
                    Text("Sign Up")
                        .padding(.vertical, 15)
                        .frame(width: 200)
                        .background(Color(secondaryColor))
                        .cornerRadius(8)
                        .foregroundColor(.white)
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Login Error"),
                      message: Text(self.authError?.localizedDescription ?? "Unknown error"),
                      dismissButton: .default(Text("OK")) {
                    if self.authError == .incorrectPassword {
                        self.user.password = ""
                    } else {
                        self.user.password = ""
                        self.user.email = ""
                    }
                    })
            }
        }
        .padding(.top, 100.0)
        .frame(width: 300)
        .textFieldStyle(RoundedBorderTextFieldStyle())
    }
}

struct SignInWithEmailView_Previews: PreviewProvider {
    static var previews: some View {
        SignInWithEmailView(showSheet: .constant(false),
                            action: .constant(.signUp),
                            primaryColor: .systemGreen,
                            secondaryColor: .systemBlue)
    }
}

struct OvalTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(10)
            .background(LinearGradient(gradient: Gradient(colors: [Color.orange, Color.orange]), startPoint: .topLeading, endPoint: .bottomTrailing))
            .cornerRadius(20)
            .shadow(color: .gray, radius: 10)
    }
}
