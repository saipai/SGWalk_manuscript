//
//  logActivityView.swift
//  SingaporeWALK
//
//  Created by CHESS on 3/6/22.
//

import SwiftUI

struct logActivityView: View {
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    private let colors: [Color] = [.red, .green, .blue, .yellow]
    @State private var isActive: Bool = false
    
    // Flexible, custom amount of columns that fill the remaining space
    private let numberColumns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // Adaptive, make sure it's the size of your smallest element.
    private let adaptiveColumns = [
        GridItem(.adaptive(minimum: 200))
    ]
    
    // Fixed, creates columns with fixed dimensions
    private let fixedColumns = [
        GridItem(.fixed(100)),
        GridItem(.fixed(100))
    ]
    var body: some View {
        
        
        NavigationView {
            
            ZStack {
                //                Color(red: 255/255, green: 255/255, blue: 255/255, opacity: 1.0)
                //                    .ignoresSafeArea()
                
                
                Banner()
                Image("dottedFootSteps")
                    .resizable()
                    .frame(width: 240, height: 140)
                    .position(x: UIScreen.main.bounds.size.width*0.6, y: -70)
                
                
                
                ScrollView{
                    
                    ScrollViewReader {
                        scroller in
                        
                        Spacer()
                        
                        Button(action: { let targetId = 10
                            scroller.scrollTo(targetId, anchor: .bottom)}) {
                                Image("arrowDown")
                                    .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                    .renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                                    .frame(width: 50.0, height: 50.0)
                                    .position(x: UIScreen.main.bounds.size.width/3 + 10, y: 0)
                                    .padding(.top, 20.0)
                            }
                        Text("Games")
                            .font(.title)
                            .bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                        
                        LazyVGrid(columns: adaptiveColumns, spacing: 1) {
                            
                            NavigationLink (destination: QuestionaireView(), isActive: $isActive)
                            {
                                HStack {
                                    
                                    ZStack {
                                        
                                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        //                                        .fill(.black.opacity(0.7))
                                            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                            .frame(width: 200, height: 200)
                                            .shadow(radius: 10)
                                            .padding()
                                        
                                        
                                        VStack {
                                            Spacer()
                                            Text("Fruit Ninja")
                                                .font(.title)
                                                .bold()
                                                .foregroundColor(.white)
                                            Image("fruitninja")
                                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                                .frame(width: 100.0, height: 100.0)
                                                .clipShape(Circle())
                                            
                                                .overlay{
                                                    Circle().stroke(.white, lineWidth:4)
                                                }
                                                .shadow(radius: 7)
                                            Spacer()
                                            
                                        }
                                    }
                                    
                                    
                                }
                            }.id(1)
                            
                            NavigationLink (destination: QuestionaireView(), isActive: $isActive)
                            {
                                HStack {
                                    
                                    ZStack {
                                        
                                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        //                                        .fill(.black.opacity(0.7))
                                            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                            .frame(width: 200, height: 200)
                                            .shadow(radius: 10)
                                            .padding()
                                        
                                        
                                        VStack {
                                            Spacer()
                                            Text("Punch Punch")
                                                .font(.title)
                                                .bold()
                                                .foregroundColor(.white)
                                            Image("punchpunch")
                                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                                .frame(width: 100.0, height: 100.0)
                                                .clipShape(Circle())
                                            
                                                .overlay{
                                                    Circle().stroke(.white, lineWidth:4)
                                                }
                                                .shadow(radius: 7)
                                            Spacer()
                                            
                                        }
                                    }
                                    
                                    
                                }
                            }.id(2)
                            
                            NavigationLink (destination: QuestionaireView(), isActive: $isActive)
                            {
                                HStack {
                                    
                                    ZStack {
                                        
                                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        //                                        .fill(.black.opacity(0.7))
                                            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                            .frame(width: 200, height: 200)
                                            .shadow(radius: 10)
                                            .padding()
                                        
                                        
                                        VStack {
                                            Spacer()
                                            Text("Step Right Up")
                                                .font(.title)
                                                .bold()
                                                .foregroundColor(.white)
                                            Image("steprightup")
                                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                                .frame(width: 100.0, height: 100.0)
                                                .clipShape(Circle())
                                            
                                                .overlay{
                                                    Circle().stroke(.white, lineWidth:4)
                                                }
                                                .shadow(radius: 7)
                                            Spacer()
                                            
                                        }
                                    }
                                    
                                    
                                }
                            }.id(3)
                            
                        }.padding(.bottom, 10.0)
                        
                        Divider()
                        Text("Exercise")
                            .font(.title)
                            .bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                        
                        LazyVGrid(columns: adaptiveColumns, spacing: 1) {
                            
                            NavigationLink (destination: QuestionaireView(), isActive: $isActive)
                            {
                                HStack {
                                    
                                    ZStack {
                                        
                                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        //                                        .fill(.black.opacity(0.7))
                                            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                            .frame(width: 200, height: 200)
                                            .shadow(radius: 10)
                                            .padding()
                                        
                                        
                                        VStack {
                                            Spacer()
                                            Text("6 Minute Walk")
                                                .font(.title)
                                                .bold()
                                                .foregroundColor(.white)
                                            Image("MascotWalk")
                                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                                .frame(width: 100.0, height: 100.0)
                                                .clipShape(Circle())
                                            
                                                .overlay{
                                                    Circle().stroke(.white, lineWidth:4)
                                                }
                                                .shadow(radius: 7)
                                            Spacer()
                                            
                                        }
                                    }
                                    
                                    
                                }
                            }
                            
                            
                            NavigationLink (destination: QuestionaireView(), isActive: $isActive)
                            {
                                HStack {
                                    
                                    ZStack {
                                        
                                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                                        //                                        .fill(.black.opacity(0.7))
                                            .fill(Color(red: 24/255, green: 28/255, blue: 98/255))
                                            .frame(width: 200, height: 200)
                                            .shadow(radius: 10)
                                            .padding()
                                        
                                        
                                        VStack {
                                            Spacer()
                                            Text("Chair Raise")
                                                .font(.title)
                                                .bold()
                                                .foregroundColor(.white)
                                            Image("MascotChairRise")
                                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                                .frame(width: 100.0, height: 100.0)
                                                .clipShape(Circle())
                                            
                                                .overlay{
                                                    Circle().stroke(.white, lineWidth:4)
                                                }
                                                .shadow(radius: 7)
                                            Spacer()
                                            
                                        }
                                    }
                                    
                                    
                                }
                            }.id(10)
                        }.padding(.bottom, 10.0)
                        Button(action: { let targetId = 1
                            scroller.scrollTo(targetId, anchor: .bottom)}) {
                                Image("arrowUp")
                                    .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                    .renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                                    .frame(width: 50.0, height: 50.0)
                                    .position(x: UIScreen.main.bounds.size.width/3 + 10, y: 0)
                                    .padding(.bottom, 20.0)
                            }
                    }
                    
                    
                }
                
                
                
                
                
                
                
            }.navigationBarTitle( !isActive ? "Start an Activity" : "Go Back to Activity", displayMode: .large)
            
            
        }.navigationViewStyle(.stack)
        
    }
}

struct logActivityView_Previews: PreviewProvider {
    static var previews: some View {
        logActivityView()
            .previewDevice("iPad (9th generation)")
        
    }
}
