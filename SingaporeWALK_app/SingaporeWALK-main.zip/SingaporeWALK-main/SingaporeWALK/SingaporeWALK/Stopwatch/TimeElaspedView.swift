//
//  TimeElaspedView.swift
//  SingaporeWALK
//
//  Created by CHESS on 15/7/22.
//

import SwiftUI



struct TimeElaspedView: View {
    @ObservedObject var stopWatchManager = StopWatchManager()
    
    var body: some View {
        VStack {
            Text("0.0")
                .font(.custom("Avenir", size: 40))
                .padding(.top, 50)
                .padding(.bottom, 50)
            if stopWatchManager.mode == .stopped {
                Button(action: {self.stopWatchManager.start()}) {
                    TimerButton(label: "Start", buttonColor: .blue)
                }
            }
            if stopWatchManager.mode == .running {
                Button(action: {self.stopWatchManager.pause()}) {
                    TimerButton(label: "Pause", buttonColor: .blue)
                }
            }
            if stopWatchManager.mode == .paused {
                Button(action: {self.stopWatchManager.start()}) {
                    TimerButton(label: "Start", buttonColor: .blue)
                }
                Button(action: {self.stopWatchManager.stop()}) {
                    TimerButton(label: "Stop", buttonColor: .red)
                }
                .padding(.top, 30)
            }
            Spacer()
        }
        
        
    }
}


struct TimerButton: View {
    
    let label: String
    let buttonColor: Color
    
    var body: some View {
        Text(label)
            .foregroundColor(.white)
            .padding(.vertical, 20)
            .padding(.horizontal, 90)
            .background(buttonColor)
            .cornerRadius(10)
    }
}

struct TimeElaspedView_Previews: PreviewProvider {
    static var previews: some View {
        TimeElaspedView()
            .previewDevice("iPad (6th generation)")
    }
}
