//
//  StatsView.swift
//  SingaporeWALK
//
//  Created by CHESS on 28/7/22.
//

import SwiftUI

struct StatsView: View {
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    @State private var selectedTab: Int = 0
    var body: some View {
        ZStack {
                Banner()
            
                VStack {
                    Picker("", selection: $selectedTab) {
                        Text("Day").tag(0)
                        Text("Week").tag(1)
                        Text("Month").tag(2)
                        Text("Year").tag(3)
                        
                    }
                    .pickerStyle(SegmentedPickerStyle())
//                        .position(x: UIScreen.main.bounds.size.width/3 + 10, y: 30)
                    
                    
                    if (selectedTab == 0){
                        DayView()                        }
                    else if (selectedTab == 1){
                        WeekView()
                    }
                }
        }.navigationBarTitle("Overview")  
    }
}

struct StatsView_Previews: PreviewProvider {
    static var previews: some View {
        StatsView()
    }
}
