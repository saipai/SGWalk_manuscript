//
//  Register.swift
//  SingaporeWALK
//
//  Created by CoolAsia on 30/6/22.
//

import SwiftUI
import Combine


struct RegisterCredView: View {
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color(.white))]
    }
    
    @State private var email = ""
    @State private var username = ""
    @State private var password = ""
    @State private var cpassword = ""
    @State private var name = ""
    
    @State private var date = Date()
    let dateRange: ClosedRange<Date> = {
        let currentDate = Date()
        var components = DateComponents()
        let calendar = Calendar.current
        
        components.calendar = calendar
        components.year = -100
        let startComponents = calendar.date(byAdding:components, to: currentDate)!
        components.year = -0
        let endComponents = calendar.date(byAdding:components, to: currentDate)!
        return startComponents
            ...
            endComponents
    }()
    
    @State private var height = "0"
    @State private var weight = "0"
    
    
    
    var body: some View {
        
        NavigationView {
            
            ScrollView {
                ZStack {
                    Banner()
                    VStack{
                        VStack (alignment: .leading){
                            
                            Text("Email: ")
                            TextField("", text: $email, onEditingChanged: {(changed) in
                                print("email onEditingChanged - \(changed)")
                            }){
                                print("email onCommit")
                            }
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.bottom)
                            .disableAutocorrection(true)
                            
                            Text("Username: ")
                            TextField("", text: $username, onEditingChanged: {(changed) in
                                print("Username onEditingChanged - \(changed)")
                            }){
                                print("Username onCommit")
                            }
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.bottom)
                            .disableAutocorrection(true)
                            
                            Text("Password: ")
                            SecureField("", text: $password)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.bottom)
                            .disableAutocorrection(true)
                            
                            Text("Confirm Password: ")
                            SecureField("", text: $cpassword)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.bottom)
                            .disableAutocorrection(true)
                            
                        }
                        .padding(.horizontal, 300)
                        .padding(.bottom)
                        .padding(.top,100)
                        
                        
                        
                        HStack{
                            VStack(alignment:.leading){
                                Text("Name: ")
                                TextField("", text: $name, onEditingChanged: {(changed) in
                                    print("Name onEditingChanged - \(changed)")
                                }){
                                    print("Name onCommit")
                                }
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding(.bottom)
                                .disableAutocorrection(true)
                            }
                            .padding(.trailing,30)
                            
                            VStack(alignment:.leading){
                                Text("Date-Of-Birth: ")
                                
                                DatePicker("",
                                           selection: $date,
                                           in: dateRange,
                                           displayedComponents: [.date])
                                .labelsHidden()
                                
                            }
                            .frame(width: UIScreen.main.bounds.size.width/8)
                        }
                        .padding(.horizontal,300)
                        
                        
                        HStack{
                            VStack(alignment:.leading){
                                Text("Height: ")
                                
                                TextField("",text:$height)
                                    .keyboardType(.numberPad)
                                    .onReceive(Just(height)) { newValue in
                                        let filtered = newValue.filter {"0123456789".contains($0)}
                                        if filtered != newValue {
                                            self.height = filtered
                                        }
                                    }
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .padding(.bottom)
                                
                            }
                            
                            Spacer()
                            
                            VStack(alignment:.leading){
                                Text("Weight: ")
                                TextField("", text: $weight)
                                    .keyboardType(.numberPad)
                                    .onReceive(Just(weight)) { newValue in
                                        let filtered = newValue.filter {"0123456789".contains($0)}
                                        if filtered != newValue {
                                            self.height = weight
                                        }
                                    }
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .padding(.bottom)
                            }
                        }
                        .padding(.horizontal,300)
                        
                        
                        
                        VStack{
                            HStack{
                                //Back button
                                NavigationLink(destination: ContentView()
                                               //                                    .navigationBarTitle("Welcome!") //this must be empty
                                    .navigationBarHidden(true)
                                    .navigationBarBackButtonHidden(true)
                                )
                                {
                                    Text("Back")
                                        .foregroundColor(.white)
                                    
                                        .frame(width: 100, height: 50)
                                        .background( Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
                                        .cornerRadius(10)
                                    
                                }
                                
                                Spacer()
                                
                                //Next button
                                NavigationLink(destination: RegisterDetailsView()
                                               //                                    .navigationBarTitle("Welcome!") //this must be empty
                                    .navigationBarHidden(true)
                                    .navigationBarBackButtonHidden(true)
                                               
                                )
                                {
                                        
                                        Text("Register")
                                            .foregroundColor(.white)
                                        
                                            .frame(width: 100, height: 50)
                                            .background( Color(red: 215/255, green: 34/255, blue: 63/255, opacity: 1.0))
                                        //                                            .padding(.top)
                                            .cornerRadius(10)
                                    
                                }
                            }
                        }
                        .padding(.horizontal,300)
                    }
                }
                .navigationTitle("Register")
            }
            
        }
        .navigationViewStyle(.stack)
        
    }
}

// Check for number only input
class NumbersOnly: ObservableObject {
    @Published var value = "" {
        didSet {
            let filtered = value.filter { $0.isNumber }
            
            if value != filtered {
                value = filtered
            }
        }
    }
}

struct RegisterCredView_Previews: PreviewProvider {
    static var previews: some View {
        ForEach(["iPad (6th generation)", "iPad Pro (12.9-inch) (5th generation)"], id: \.self) { deviceName in
            RegisterCredView()
                .previewInterfaceOrientation(.landscapeRight)
                .environmentObject(LaunchScreenManager())
                .previewDevice(PreviewDevice(rawValue: deviceName))
                .previewDisplayName(deviceName)
        }
    }
}
